/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RealEstateSA;

/**
 *
 * @author Kiran P
 */
import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import javax.swing.*;
 
public class graphs extends JPanel {
    
    public static void graphs1()
    {
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try
        {
       f.add(new graphs());
        }
        catch(Exception e)
                {
                    //System.out.println(""+e);
                }
        f.setSize(800,500);
        f.setLocation(300,200);
        f.setVisible(true);
    }
    
    
    
   static int[] data = {
       2,5,7,9,3,5,11,9,6,5,4,2,9,8,4,7,3,9,5,8,6,9,4,2
    }; 
 public  int data1[]=new int [data.length+5];
    final int PAD = 20;
    static double distance[]=new double[data.length];
    static double m;
    public static int [] newData=new int [5];
    public static void dist()
    {
    int c=data.length;
    m=data[(c-1)]/c;
    double d=(m*m)+1;
    double v=Math.sqrt(d);
    for(int j=0;j<c;j++)
    {
    distance[j]=Math.abs(m*j- data[j])/v;
    System.out.format("distance = %.2f \n", distance[j]);
    //System.out.println("distance=%.2lf"+distance[j]);
    }
    }

       
            

        public static double calculateSD(double distance[])
        {
            double sum = 0.0, standardDeviation = 0.0;

            for(double num : distance) {
                sum += num;
            }

            double mean = sum/20;

            for(double num: distance) {
                standardDeviation += Math.pow(num - mean, 2);
            }

            return Math.sqrt(standardDeviation/20);
        
    }
 
    protected void paintComponent(Graphics g) {
    	 dist(); 
    	int totalUnsold=50;

    	        double SD = calculateSD(distance);
    	        //.setPrecision(2);

    	        System.out.format("Standard Deviation = %.2f \n", SD);
    	        double var=Math.floor(SD)*Math.floor(SD);
    	       // System.out.println(var);
    	      
    	        int i=data.length;
    	        newData[0]= (int)Math.floor(data[i-1]+var);
    	        
    	        totalUnsold-=newData[0];
    	        int j1;
    	        for(j1=1;!(totalUnsold<=0);j1++)
    	        {
    	        	
    	        	//System.out.println("hey");
    	         newData[j1]=(int) Math.floor(newData[j1-1]+var);
    	        // int g3=newData[j1];
    	         System.out.println("newData=" +newData[j1]);
    	        if(newData[j1]<=totalUnsold) {
    	            
    	        totalUnsold-=newData[j1];
    	        System.out.println("newData=" +newData[j1]);
    	         }
    	         else
    	        break;
    	        }
    	        newData[j1]=totalUnsold;
    	        int newdata = totalUnsold;
    	        totalUnsold-=newdata;
    	        System.out.println("totalUnsold="+totalUnsold);
    	        
    	        for(int k=0;k<data.length;k++)
    	        {
    	        	data1[k]=data[k];
    	        }
    	        for(int f=data.length,l=0;f<(data.length+newData.length);f++,l++)
    	        {
    	        	data1[f]=newData[l];
    	        }
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        // Draw ordinate.
        g2.draw(new Line2D.Double(PAD, PAD, PAD, h-PAD));
        // Draw abcissa.
        g2.draw(new Line2D.Double(PAD, h-PAD, w-PAD, h-PAD));
        // Draw labels.
        Font font = g2.getFont();
        FontRenderContext frc = g2.getFontRenderContext();
        LineMetrics lm = font.getLineMetrics("0", frc);
        float sh = lm.getAscent() + lm.getDescent();
        // Ordinate label.
        String s = "unsold units";
        float sy = PAD + ((h - 2*PAD) - s.length()*sh)/2 + lm.getAscent();
        for(int i1 = 0; i1 < s.length(); i1++) {
            String letter = String.valueOf(s.charAt(i1));
            float sw = (float)font.getStringBounds(letter, frc).getWidth();
            float sx = (PAD - sw)/2;
            g2.drawString(letter, sx, sy);
            sy += sh;
        }
        // Abcissa label.
        s = "Months";
        sy = h - PAD + (PAD - sh)/2 + lm.getAscent();
        float sw = (float)font.getStringBounds(s, frc).getWidth();
        float sx = (w - sw)/2;
        g2.drawString(s, sx, sy);
        // Draw lines.
        double xInc = (double)(w - 2*PAD)/(data1.length-1);
        double scale = (double)(h - 2*PAD)/getMax();
        g2.setPaint(Color.green.darker());
        for(int i1 = 0; i1 < data1.length-1; i1++) {
            double x1 = PAD + i1*xInc;
            double y1 = h - PAD - scale*data1[i1];
            double x2 = PAD + (i1+1)*xInc;
            double y2 = h - PAD - scale*data1[i1+1];
            g2.draw(new Line2D.Double(x1, y1, x2, y2));
        }
        // Mark data points.
        g2.setPaint(Color.red);
        for(int i1 = 0; i1 < data1.length; i1++) {
            double x = PAD + i1*xInc;
            double y = h - PAD - scale*data1[i1];
            g2.fill(new Ellipse2D.Double(x-2, y-2, 4, 4));
        }
    }
 
    private int getMax() {
        int max = -Integer.MAX_VALUE;
        for(int i = 0; i < data1.length; i++) {
            if(data1[i] > max)
                max = data1[i];
        }
        return max;
    }
 
    /*public static void main(String[] args) {
    	
    	      
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(new graphs());
        f.setSize(400,400);
        f.setLocation(200,200);
        f.setVisible(true);
    }*/
}